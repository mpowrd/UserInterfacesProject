import React from 'react';
import './App.css';
import EurovisionDataTable from './EurovisionDataTable.js'; 
import data from './canciones.json'; // Assuming your JSON file is named data.json and is in the same directory
import { useEffect, useState } from "react";



function App() {

  const [filtroAño, setFiltroAño] = useState(""); // Estado para el filtro


  // Filtrar datos por año
  const datosFiltrados = data.filter((item) =>
    filtroAño ? item.year.toString().includes(filtroAño) : true
  );

  return (
    <div style={{ padding: "20px" }}>
      <h1>Tabla con Filtro por Año</h1>

      {/* Input para filtrar */}
      <input
        type="number"
        placeholder="Filtrar por año..."
        value={filtroAño}
        onChange={(e) => setFiltroAño(e.target.value)}
      />

      {/* Tabla */}
      <table border="1" cellPadding="10" style={{ marginTop: "10px" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>name</th>
            <th>artist_name</th>
          </tr>
        </thead>
        <tbody>
          {datosFiltrados.map((item) => (
            <tr key={item.id}>
              <td>{item.year}</td>
              <td>{item.song_name}</td>
              <td>{item.artist_name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

}

export default App;
