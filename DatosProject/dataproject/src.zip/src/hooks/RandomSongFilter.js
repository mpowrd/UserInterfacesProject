import UseDataLoader from "./useDataLoader";
import React, {useEffect,useState} from "react";

const RandomSongFilter = (columna_filtrado) => {
    const [fila_random,SetFila_random] = useState({})
    useEffect(() => {
        try{

        }catch (err){
            console.error("Error al filtrar los datos, añade los valores válidos")
        }
    });


    return fila_random;
}

export default RandomSongFilter;
